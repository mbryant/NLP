import java.io.IOException;

public class BigramTrainer {

	BigramDictionary dict;
	WordReader wr;
	
	// constructs a new Bigram Trainer on corpus fileName
	public BigramTrainer(String fileName) {
		this.wr = new WordReader(fileName);
		this.dict = new BigramDictionary();
	}
	
	// go through the training file and add all the bigrams
	// to the bigram dictionary
	public void buildCounts() throws IOException {
		this.wr.openFile();
		String wd1, wd2;
		
		if (this.wr.hasNextItem()) {
			wd1 = this.wr.readWord();
		} else {
			throw new IOException("there is just nothing in the darn file");
		}
		
		while (this.wr.hasNextItem()) {
			wd2 = this.wr.readWord();
			this.dict.insertBigram(wd1, wd2);
			wd1 = wd2;
		}
		
		this.wr.closeFile();
	}
	
	
	
	
	
	
}
